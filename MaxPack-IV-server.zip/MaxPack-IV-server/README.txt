--How to make a server on your PC:--
Open the forge-1.17.1-37.0.68-installer and install server into a new folder 
> Drag Mods Folder, Configs Folder and server.properties into the new folder you made 
> Open the  the run.bat
> After it says click any button to continue, do that
> Accept EULA agreement 
> Launch the run.bat file again


Q: I'm trying to run a server but it's not working, how do I fix this?
A: You need to use Java 16, 64-bit to run a modded Minecraft server. You can download it from here: https://adoptopenjdk.net/ - select OpenJDK 16 (Latest)

